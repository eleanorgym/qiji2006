<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Mb99.net - Mb99.net</title>
<!-- <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> -->
 <style type="text/css">
		 #categories { 	width: 700px;
 }
#categories a { 	display: block;
	width: 230px;
	padding: 1.5px;
	font-family: verdana, arial, sans-serif;
	font-size: 11px;
	text-decoration: none;
	color: #000066;
 }
#categories a:hover { 	text-decoration: underline;
 }
#header { 	font-family: arial, sans-serif;
	color: #666;
 }
#header em { 	font-size: 11px;
	font-style: normal;
	display: block;
 }
#header strong { 	font-weight: bold;
	font-size: 14px;
	text-transform: uppercase;
 }
#main-content .searchbox  { float: right; }
#masthead {    margin: 11px auto; }
#navcontainer { font-style: italic;
font-size: 11px;
font-family: verdana, arial, sans-serif;
margin-bottom: 19px;
text-align: left; }
#navlist { padding: 0;
margin: 0;
border-top: 1px solid black; }
#navlist li { list-style: none;
font-style: normal;
margin: 0;
padding: 0;
font-size: 11px;
border-bottom: 1px solid #ccc;
font-weight: bold;
line-height: 18px; }
#navlist li a { text-decoration: none; display: block; margin: 0; padding: 2px 0 2px 4px; color: #444; }
#navlist li a:hover { background: #f5f5f5; }
#navlist ul { margin: 0;
padding: 0; }
#sidebar { padding-top: 18px; }
#top-links {  font-size: 11px; color: #fff; text-decoration: none; }
#top-links a {  color: #fff;
text-decoration : none; }
#top-links a:hover { text-decoration: underline; }
.divider_bg { 	background: url(http://images.bmnq.com/tplg/39/divider_bg.gif) repeat-x left top;
	display: block;
	margin: 8px 0;
	padding: 0;
 }
.domainname { font-family: trebuchet ms, arial, sans-serif;
font-size: 21px;
color: #555;
float: left; }
.expiry_note { 
	font-family: tahoma;
	font-size: 11px;
	color: #555;
	margin: 0;
	padding: 0;	
 }
.featured_list { text-align: left;
	display: block;
	width: 210px;
	margin: 0;
	padding: 0; }
.featured_list li { 	width: 210px;	
	list-style: none;
	font-size: 14px;
	font-weight: bold;
	margin: 0 0 0 5px;
	padding: 0; }
.featured_list li a { text-decoration: underline;color: #000;line-height: 18px;padding: 2px 0;
background: url(http://images.bmnq.com/tplg/39/featured_listing_bullet.gif) no-repeat left center; padding-left: 8px; font-weight:normal;font-size:14px;font-family:arial, sans-serif }
.featured_list li a:hover { color: #cc0000;
background: url(http://images.bmnq.com/tplg/39/featured_listing_bullet.gif) no-repeat left center;
text-decoration: none;


 }
.featured_section { 
	border: 1px solid #EAEDE1;
 }
.featured_title { 
	background: #EAEDE1;
	font-size: 10px;
	font-family: verdana;
	color: #576039;
	display: block;
	margin: 0;
	padding: 4px 0 4px 11px;
	font-weight: bold;
 }
.footer { 
	border: 1px solid #EAEDE1;
 }
.footer_bookmark { 
	font-size: 21px;
	font-family: georgia;
	background: #EAEDE1;
 }
.listing { 
	margin: 0;
	padding: 0;
	border-top: 1px solid #bababa;
	width: 278px;
	text-align: left;
	display: block;
 }
.listing li { 
	list-style: none;
	width: 276px;
	display: block;
	margin: 0 0 3px 0;
 }
.listing li a { display: block;text-decoration: none;width: 256px !important;width: 277px;color: #003399;font-size: 12px;font-weight: bold;padding: 6px 0 6px 21px;background: url(http://images.bmnq.com/tplg/39/listing_icon.gif) #f5f5f5 no-repeat 5px center;line-height: }
.listing li a:hover { 	background: url(http://images.bmnq.com/tplg/39/listing_icon.gif) #EAEDE1 no-repeat 5px center;
 }
.related-categories { 	font: 11px/18px verdana, arial, sans-serif;
 }
.related-categories a { 	text-decoration: none;
	color: #333333;
	display: block;
	/*padding: 2px 0;*/
 }
.related-categories a:hover { color: #cc0000;
text-decoration: underline; }
.related-categories td { 	font: 11px/18px verdana, arial, sans-serif;
	padding-left: 6px !important;
	padding-left: 16px;
 }
.related-searches a { 	font-weight: bold;
	text-decoration: none;
	color: #330066;
	display: block;
	padding: 3px 0 3px 0px;
 }
.related-searches a:hover { 	text-decoration: underline;
 }
.related-searches td { 	font: 13px/18px verdana, arial, sans-serif;
	padding-left: 17px !important;
	padding-left: 19px;
 }
.related_categories { 	width: 180px;
	background: url(http://images.bmnq.com/tplg/39/corner.gif) #eee no-repeat right top;
	text-align: left;

 }
.related_categories li { 
	text-decoration: none;
	color: #333;
	display: block;
	padding: 0;
	margin: 5px 0;
 }
.related_categories li a { 	text-decoration: none;
	color: #333;

 }
.related_categories li a:hover { 	color: #CC6600;
 }
.related_categories ul { 
	margin: 1.5em 1em;
	list-style: none;
	padding: 0;
	font-size: 12px;
	font-family: arial, sans-serif;
 }
.related_categories ul strong { 
display: block;
font-family: Arial, 'trebuchet ms';
border-bottom: 1px solid #fff;
font-size: 12px;
margin-bottom: 8px;
width: 140px; height: 20px;
 }
.related_categories2 { 	width: 180px;
	background: url(http://images.bmnq.com/tplg/39/pin.gif) #eeeedd no-repeat right top;
	text-align: left;

 }
.related_categories2 li { 	text-decoration: none;
	color: #333;
	display: block;
	padding: 0;
	margin: 5px 0;

 }
.related_categories2 li a { 	text-decoration: none;
	color: #000;

 }
.related_categories2 li a:hover { 	color: #CC6600;
 }
.related_categories2 ul { 	margin: 1.5em 1em;
	list-style: none;
	padding: 0;
	font-size: 12px;
	font-family: arial, sans-serif;

 }
.related_categories2 ul strong { display: block;
font-family: Arial, 'trebuchet ms';
border-bottom: 1px solid #fff;
font-size: 12px;
margin-bottom: 8px;
width: 140px; height: 20px;
 }
.spons a { color: navy; font-family: verdana, helvetica, sans-serif; font-weight: bold;font-size: 11pt; color: #000066; }
.spons a:hover { color: navy; font-family: verdana, helvetica, sans-serif; font-size: 11pt; font-weight: bold; text-decoration: none; }
.sponsored_results { background: url(http://images.bmnq.com/tplg/39/bg.gif) repeat-x left top;
padding-left: 8px;
 }
.sponsored_results .head { 
font-size: 14px;
font-weight: bold;
text-decoration: none;
margin-bottom: 1px;
color: #000066;
 }
.sponsored_results .url { 
font-size: 11px;
color: #000066;
 }
.sponsored_results em { 
	font-family: tahoma;
	color: #888;
	font-size: 11px;
	font-style: normal;
 }
.sponsored_results p { 	font-size: 12px;
	color: #333;

 }
.sponsoredlinks { font-family: verdana, arial, sans-serif;
font-size: 11px;
text-align: left; }
.sponsurl a { color: #5196E1; font-family: verdana, helvetica, sans-serif; font-size: 8pt; }
.sponsurl a:hover { color: #5196E1; font-family: verdana, helvetica, sans-serif; font-size: 8pt; text-decoration: none; }
.text  { font-family: verdana, helvetica, sans-serif; font-size: 9pt; }
a:hover { 	color: orange;	
 }
body { 
	margin: 0;
	padding: 0;
	font-family: verdana, arial, sans-serif;
	color: #000;
 }
h1 { 
	font-family: arial, san-serif;
	font-size: 21px;
	margin: 0;
	padding: 0;	
 }
table,  td {        font-family: verdana, arial, sans-serif;
	font-size: 11px; }
.featured_list2 { text-align: left;
	display: block;
	width: 210px;
	margin: 0;
	padding: 0; }
.featured_list2 li { width: 210px;list-style: none;margin: 0 0 0 5px;padding: 0; }
.featured_list2 li a { text-decoration: none; color: #000; line-height: 18px;padding: 2px 0;
background: url(http://images.bmnq.com/tplg/39/featured_listing_bullet.gif) no-repeat left center;padding-left: 8px; font-weight:normal;font-size: 8pt;font-family: Verdana; }
.featured_list2 li a:hover { color: #cc0000;
background: url(http://images.bmnq.com/tplg/39/featured_listing_bullet.gif) no-repeat left center;
text-decoration: none; }

 </style>


 <script language="JavaScript" type="text/javascript">
		<!-- Begin //
		
		var SrchBtn_clicked = false;		
		function clear_SrchText(SrchObj)	
		{
			if((SrchBtn_clicked == false) && (SrchObj.value == "Enter Keyword"))
			{
			    SrchObj.value = "";
			}
		    SrchObj.select();
		}

		function replaceall(string,text,by) {
		// Replaces text with by in string
		    var strLength = string.length, txtLength = text.length;
		    if ((strLength == 0) || (txtLength == 0)) return string;

		    var i = string.indexOf(text);
		    if ((!i) && (text != string.substring(0,txtLength))) return string;
		    if (i == -1) return string;

		    var newstr = string.substring(0,i) + by;

		    if (i+txtLength < strLength)
			newstr += replaceall(string.substring(i+txtLength,strLength),text,by);

		    return newstr;
		}


		function submit_action(formname, type, position) {
		    d = document.forms[formname];
		    if ((d.elements['q'].value.length == 0) || (d.elements['q'].value == "Enter Keyword"))
		    {
			alert("Please enter a search keyword !");
			d.elements['q'].focus();
			return false;
		    }
		    else
		    {
			newstr = replaceall(d.elements['q'].value," ","_");
//			newstr = URLEncode(newstr);
			newstr = escape(newstr);
			d.action = '/' + newstr +".cfm?nft=1&t=" + type + "&p=" + position;
		    }
		    return true;
		}

		function url_change(url) {
			    s = decodeBase64(url);
	 	        window.location = s;
		}

		
		function sendRequest(thisform, strElement) 
		{
			thisform = document.getElementById("frmSponsAds");
			var strforms = strElement;
			var arrElement = new Array();
			arrElement = strforms.split("@@@@");
			for(var i=0; i<arrElement.length; i++)
			{
				var arrTemp = new Array();
				var strTemp = new String(arrElement[i]);
				arrTemp = strTemp.split("####");
				switch(arrTemp[0])
				{
					case "action":
						thisform.action = arrTemp[1]+'&t=&p=';
						break;
					case "data":
						thisform.param6.value = arrTemp[1];
						break;
					case  "domain":
						thisform.domain.value = arrTemp[1];
						break;
					case "tr":
						thisform.param1.value = arrTemp[1];
						break;
					case "vurl":
						thisform.param2.value = arrTemp[1];
						break;					
					case "l1":
						thisform.param3.value = arrTemp[1];
						break;						
					case "q":
						thisform.q.value = arrTemp[1];
						break;
				}

			}
			thisform.method = "POST";
			thisform.submit();
			return(false);
		}

		function URLEncode(strValue)
		{

			var SAFECHARS = "0123456789" +					// Numeric
							"ABCDEFGHIJKLMNOPQRSTUVWXYZ" +	// Alphabetic
							"abcdefghijklmnopqrstuvwxyz" +
							"-_.!~*'()";		// RFC2396 Mark characters
			var HEX = "0123456789ABCDEF";

			var plaintext = strValue;
			var encoded = "";
			for (var i = 0; i < plaintext.length; i++ ) {
				var ch = plaintext.charAt(i);
				if (ch == " ") {
					encoded += "+";	// x-www-urlencoded, rather than %20
				} else if (SAFECHARS.indexOf(ch) != -1) {
					encoded += ch;
				} else {
					var charCode = ch.charCodeAt(0);
					if (charCode > 255) {
						alert( "Unicode Character '" 
								+ ch 
								+ "' cannot be encoded using standard URL encoding.\n" +
								  "(URL encoding only supports 8-bit characters.)\n" +
								  "A space (+) will be substituted." );
						encoded += "+";
					} else {
						encoded += "%";
						encoded += HEX.charAt((charCode >> 4) & 0xF);
						encoded += HEX.charAt(charCode & 0xF);
					}
				}
			} // for
			return(encoded);
		};

		
		function changeStatus(keyword) 
		{
		    window.status = keyword;
		    return true;
		}




		function PopNav(Url)
		{
			if(Url != "-1" && Url != "-1")
			{
				location.href = Url;
			}
		}


		function addbookmark()
		{
		bookmarkurl="http://www.mb99.net"
		bookmarktitle="Welcome To Mb99.net"
		if (document.all)
		window.external.AddFavorite(bookmarkurl,bookmarktitle)
		return(false);
		}


 		function HandleLoc()
		{
			var strUrl;
			strUrl = 'http://images.bmnq.com';strUrl += '/lt.php?dn=';strUrl += 'mb99.net';strUrl += '&ck=bizcn25079';strUrl += '&isbn=';strUrl += '0';strUrl +=	'&uid=1&k=16mm+films';							
			location.href = strUrl;
			return true;
		}



		//  End -->
  </script>


<script type='text/javascript' language='javascript'>

function pp () {

        newpop = window.open('/1st?dn=Mb99.net&cid=bizcn25079', 'newpop', 'directories=0,menubar=0,width=700,height=370');
    this.focus();

}

</script>




</head>
<!-- keyword start -->
<body onload="pp()"><!-- <br> --><!-- keyword end -->


	

	
<br>
<!-- HEADER -->
<table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr> 
		<td width="54" height="50" align="left" valign="middle">
			<img src="../tplg/39/header-name.gif" border="0" align="left" width="48" height="50">
		</td>
		<td width="359" valign="middle">
			<h1>Mb99.net</h1>
		</td>
		<td width="337" align="center" valign="middle">
			<p class="expiry_note" style="margin-bottom: 10px;">
							
						                 <A HREF="http://www.bizcn.com/"><img src="../tplg/bizcn-link.gif" border="0"/></a><br/>
    This domain has expired. <A HREF="http://www.cnobin.com/">Click here</a> to renew it.


											</p>
			<form name="form2" onsubmit="return submit_action('form2', 5, 1)" method="post">
				<input type="text" name="q" size="23" style="font-family: Verdana; font-size:8pt" value="Enter Keyword" onClick="clear_SrchText(this)" >
				<input type="submit" value="Search!" name="B1" style="width: 91px; font-family: verdana; font-size:10px; font-weight:bold; background-color:#CCCC99">
			</form>
		</td>
	</tr>
</table>
<!-- /HEADER -->

<!-- MASTHEAD -->
<br>

<!-- DIVIDER BACKGROUND -->
<div class="divider_bg">
	<img src="../tplg/39/divider_bg.gif" border="0">
</div>
<!-- /DIVIDER BACKGROUND -->

<!-- /MASTHEAD -->

<!-- MAIN TABLE -->
							<!-- LISTINGS SECTIONS -->
			<table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
				<tr>
				<!-- FIRST LISTING SECTION -->
					<td width="375" height="65" valign="top" align="center" nowrap>
					<div style='display:none;'><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a></div>						<!-- img src="../tplg/39/listing_header_1.jpg" border="0" -->
						<img src="../tplg/39/listing_header_txt1.gif" border="0">
						<ul class="listing">
																				
											<li>
											<A href="/16mm_films.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('16mm Films');return true;" onmouseout="changeStatus('');return true;" target="_top">16mm Films</a></li>
																																																	
											<li>
											<A href="/insurance.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Insurance');return true;" onmouseout="changeStatus('');return true;" target="_top">Insurance</a></li>
																																																	
											<li>
											<A href="/online_dvd_rental.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Online Dvd Rental');return true;" onmouseout="changeStatus('');return true;" target="_top">Online Dvd Rental</a></li>
																																																	
											<li>
											<A href="/education_online.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Education Online');return true;" onmouseout="changeStatus('');return true;" target="_top">Education Online</a></li>
																																																	
											<li>
											<A href="/buy_short_films.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Buy Short Films');return true;" onmouseout="changeStatus('');return true;" target="_top">Buy Short Films</a></li>
																																															
						</ul>
					</td>
				<!-- /FIRST LISTING SECTION -->

				<!-- SECOND LISTING SECTION -->
					<td width="375" valign="top" align="center" nowrap>
					<div style='display:none;'><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a></div>						<!-- img src="../tplg/39/listing_header_2.jpg" border="0" -->
						<img src="../tplg/39/listing_header_txt2.gif" border="0">
						<ul class="listing">
																																							
											<li>
											<A href="/music_download.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Music Download');return true;" onmouseout="changeStatus('');return true;" >Music Download</a></li>
																																																	
											<li>
											<A href="/music_downloading.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Music Downloading');return true;" onmouseout="changeStatus('');return true;" >Music Downloading</a></li>
																																																	
											<li>
											<A href="/student_loan.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Student Loan');return true;" onmouseout="changeStatus('');return true;" >Student Loan</a></li>
																																																	
											<li>
											<A href="/australia_travel_agents.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Australia Travel Agents');return true;" onmouseout="changeStatus('');return true;" >Australia Travel Agents</a></li>
																																																	
											<li>
											<A href="/trust.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Trust');return true;" onmouseout="changeStatus('');return true;" >Trust</a></li>
																													
						</ul>
					</td>
				<!-- /SECOND LISTING SECTION -->
				</tr>
			</table>
			<!-- /LISTINGS SECTIONS -->
			<br>

			<!-- FEATURED SECTION -->
			<table width="660" border="0" align="center" cellpadding="0" cellspacing="0" class="featured_section">
				<tr> 
					<td height="22" colspan="3" valign="top">
						<p class="featured_title">� featured listing</p>
					</td>
				</tr>
				<tr> 
					<td width="220" height="101" valign="middle" align="center" nowrap>
						<img src="../tplg/39/featured_header_1.jpg" border="0">
					</td>
				
					<!-- FIRST FEATURED LISTING -->
					<td width="220" valign="middle" align="middle" nowrap>
						<ul class="featured_list">
															<li>
								<A href="/download-free-music.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Download-free-music');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Download-free-music</a></li>
															<li>
								<A href="/african_american_dating.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('African American Dating');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">African American Dating</a></li>
															<li>
								<A href="/downloading_mp3s.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Downloading Mp3s');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Downloading Mp3s</a></li>
															<li>
								<A href="/health_and_beauty.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Health And Beauty');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Health And Beauty</a></li>
																	
						</ul>
						<div style='display:none;'><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a></div>					</td>
					<!-- /FIRST FEATURED LISTING -->
				
					<!-- SECOND FEATURED LISTING -->
					<td width="220" valign="middle" align="left" nowrap>
						<ul class="featured_list">
															<li>
								<A href="/travel.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Travel');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Travel</a></li>		
															<li>
								<A href="/16mm_projektor.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('16mm Projektor');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">16mm Projektor</a></li>		
															<li>
								<A href="/dvd_online_rental.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Dvd Online Rental');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Dvd Online Rental</a></li>		
															<li>
								<A href="/balanced_scorecard.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Balanced Scorecard');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Balanced Scorecard</a></li>		
																		
						</ul>
					</td>
					<!-- /SECOND FEATURED LISTING -->		
				</tr>
			</table>
			<!-- /FEATURED SECTION -->
			<br />
			<!-- FEATURED SECTION -->
			<table class="featured_section" align="center" border="0" cellpadding="0" cellspacing="0" width="660">
				<tbody>
				<tr> 
					<td colspan="3" height="22" valign="top">
					<div style='display:none;'><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a></div>						<p class="featured_title">� popular topics</p>
					</td>

				</tr>
				<tr> 
					<!-- FIRST FEATURED LISTING -->
					<td align="left" height="101" nowrap="nowrap" valign="middle" width="220">
						<ul class="featured_list2">
															<li>
								<A href="/controlling.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Controlling');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Controlling</a></li>
															<li>
								<A href="/online_dating.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Online Dating');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Online Dating</a></li>
															<li>
								<A href="/computer_notebooks.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Computer Notebooks');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Computer Notebooks</a></li>
															<li>
								<A href="/jobs.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Jobs');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Jobs</a></li>
															<li>
								<A href="/35mm_film.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('35mm Film');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">35mm Film</a></li>
																		
						</ul>
					</td>
					<!-- /FIRST FEATURED LISTING -->

					<!-- SECOND FEATURED LISTING -->
					<td align="left" height="101" nowrap="nowrap" valign="middle" width="220">
						<ul class="featured_list2">
															<li>
								<A href="/film.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Film');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Film</a></li>
															<li>
								<A href="/credit_card.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Credit Card');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Credit Card</a></li>
															<li>
								<A href="/music.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Music');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Music</a></li>
															<li>
								<A href="/soul_music.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Soul Music');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Soul Music</a></li>
															<li>
								<A href="/the_songs_of_lilo_and_stitch.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('The Songs Of Lilo And Stitch');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">The Songs Of Lilo And Stitch</a></li>
																		
						</ul>
					</td>
					<!-- /SECOND FEATURED LISTING -->

					<!-- THIRD FEATURED LISTING -->
					<td align="left" height="101" nowrap="nowrap" valign="middle" width="220">
						<ul class="featured_list2">
															<li>
								<A href="/professional_services.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Professional Services');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Professional Services</a></li>
															<li>
								<A href="/sex.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Sex');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Sex</a></li>
															<li>
								<A href="/argentina_travel.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Argentina Travel');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Argentina Travel</a></li>
															<li>
								<A href="/.com_airway_british.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('.com Airway British');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">.com Airway British</a></li>
															<li>
								<A href="/entertainment_in_las_vegas.cfm?nft=1&t=4&p=4"  onmouseover="changeStatus('Entertainment In Las Vegas');return true;" onmouseout="changeStatus('');return true;"  nowrap="true">Entertainment In Las Vegas</a></li>
																		
						</ul>	  
						<div style='display:none;'><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a><a href="#" onclick="return HandleLoc();"><img src="../px.gif" width=0 height=0 border=0></a></div>					</td>
					<!-- /THIRD FEATURED LISTING -->			
				</tr>
				</tbody>
			</table>
				
			<!-- /FEATURED SECTION -->
				

		<br>

		<!-- FOOTER WITH BOOKMARK AND SEARCH -->
			<!--
			<table width="660" border="0" align="center" cellpadding="2" cellspacing="2" class="footer">
			  <tr> 
				<td align="center" valign="middle" class="footer_bookmark">
					<a href=""  onclick="addbookmark();return false;" nowrap style="font-family: verdana, sans-serif; font-size: 9pt; color:black">Bookmark This Page!</a>
				</td>
				<td width="480" valign="middle" align="center" nowrap>
					<form name="form3" onsubmit="return submit_action('form3', 6, 1)" method="post" style="margin: 0; padding: 0;">
						<input type="text" name="q" size="51" style="font-family: Verdana; font-size:8pt" value="Enter Keyword" onClick="clear_SrchText(this)" >

						<input type="submit" value="Search!" name="B1" style="width: 111px; font-family: verdana; font-size:10px; font-weight:bold; background-color:#CCCC99">
					</form>
				</td>
			  </tr>
			</table>
			-->
			<table class="footer" align="center" border="0" cellpadding="2" cellspacing="2" width="660">
			  <tbody><tr> 
				
				<td align="center" nowrap="nowrap" valign="middle">
					<form name="form3" onsubmit="return submit_action('form3', 6, 1)" method="post" style="margin: 0pt; padding: 0pt;">
						<input name="q" size="71" style="font-family: Verdana; font-size: 8pt;" value="Enter Keyword" onclick="clear_SrchText(this)" type="text">
				</td>

				<td align="center" nowrap="nowrap" valign="middle">
						<input value="Search!" name="B1" style="width: 141px; font-family: verdana; font-size: 10px; font-weight: bold; background-color: rgb(204, 204, 153);" type="submit">

					</form>
				</td>

			  </tr>
			</tbody></table>
		   <!--
             <p align="center"><span style='font-family: Arial;font-size:11px;'>Copyright � 2005, mb99.net All Rights Reserved.</span></p>
		   -->
     <!-- /FOOTER WITH BOOKMARK AND SEARCH -->
		<br>

<!-- cps -->
<!-- cpe -->


<!-- Form to submit Sponsored Ads -->
<div style="visibility:hidden" id="divSponAds">
	<form name="frmSponsAds" id="frmSponsAds" mothod="POST" action="" target="_top">
		<input type="hidden" name="param1" id="param1">
		<input type="hidden" name="param2" id="param2">
		<input type="hidden" name="param3" id="param3">
		<input type="hidden" name="q" id="q">
		<input type="hidden" name="domain" id="domain">
		<input type="hidden" name="param6" id="param6">
	</form>
</div>
<br>
<!-- Test -->
</body>
</html><!--
     FILE ARCHIVED ON 20:05:47 Apr 20, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 22:34:16 Dec 15, 2024.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->
<!--
playback timings (ms):
  captures_list: 0.681
  exclusion.robots: 0.027
  exclusion.robots.policy: 0.012
  esindex: 0.014
  cdx.remote: 7.018
  LoadShardBlock: 93.168 (3)
  PetaboxLoader3.datanode: 101.836 (4)
  PetaboxLoader3.resolve: 199.387 (2)
  load_resource: 228.67
-->