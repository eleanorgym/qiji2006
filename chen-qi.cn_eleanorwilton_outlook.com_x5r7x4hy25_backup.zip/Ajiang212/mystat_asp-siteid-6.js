var ajstat_siteid	= '6'
var ajstat_style	= '';
var ajstat_url		= 'http://www.guing.net/Ajiang212/';
var ajstat_ndate	= new Date();
var ajstat_tzone	= 0 - ajstat_ndate.getTimezoneOffset()/60;
var ajstat_tcolor	= screen.colorDepth;
var ajstat_sSize	= screen.width + ',' + screen.height;
var ajstat_referrer	= escape(document.referrer);
var ajstat_outstr	= '<script language=javascript src=' + ajstat_url 
			  + 'stat.asp?style=' + ajstat_style 
			  + '&siteid=' + ajstat_siteid 
			  + '&tzone=' + ajstat_tzone 
			  + '&tcolor=' + ajstat_tcolor
			  + '&sSize=' + ajstat_sSize
			  + '&referrer=' + ajstat_referrer
			  + '><\/script>';
document.write(ajstat_outstr);

function ajstatimgon(reftime){
  var ttime=new Date();
  var ajstat_img=new Image();
  ajstat_img.src=ajstat_url+'stat_online.asp?siteid='+ajstat_siteid+'&o='+ttime.getDate+ttime.getMinutes +ttime.getSeconds;
  var ajstatimgtimeout=setTimeout('ajstatimgon('+reftime+');',reftime);
}
ajstatimgon(40000);