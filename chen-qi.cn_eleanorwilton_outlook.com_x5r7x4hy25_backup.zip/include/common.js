// JavaScript Document

//判断邮件地址
function isEmail(str){
	var patrn=/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	if (!patrn.exec(str)) 
		{return false;}
	return true;			
}
//判断电话或传真号码
function isTel(str){
	//var patrn=/^((\(\d{3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}$/;
	var patrn=/^(\d){1,3}[ ]?([-]?((\d)|[ ]){1,12})+$/;
	if (!patrn.exec(str))
		{return false;}
	return true;
}
//判断邮政编码

function isPostCode(str){
	var patrn=/^[0-9]{6}$/;
	if (!patrn.exec(str))
		{return false;}
	return true;
}