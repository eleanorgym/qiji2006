<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html dir=ltr>

<head>
<style> a:link			{font:9pt/11pt ����; color:FF0000} a:visited		{font:9pt/11pt ����; color:#4e4e4e}
</style>

<META NAME="ROBOTS" CONTENT="NOINDEX">

<title>�޷��ҵ���ҳ</title>

<META HTTP-EQUIV="Content-Type" Content="text-html; charset=gb2312">
<META NAME="MS.LOCALE" CONTENT="ZH-CN">
</head>

<script>
function Homepage(){
<!--
// in real bits, urls get returned to our script like this:
// res://shdocvw.dll/http_404.htm#http://www.DocURL.com/bar.htm

	//For testing use DocURL = "res://shdocvw.dll/http_404.htm#https://www.microsoft.com/bar.htm"
	DocURL = document.URL;

	//this is where the http or https will be, as found by searching for :// but skipping the res://
	protocolIndex=DocURL.indexOf("://",4);

	//this finds the ending slash for the domain server
	serverIndex=DocURL.indexOf("/",protocolIndex + 3);

		//for the href, we need a valid URL to the domain. We search for the # symbol to find the begining
	//of the true URL, and add 1 to skip it - this is the BeginURL value. We use serverIndex as the end marker.
	//urlresult=DocURL.substring(protocolIndex - 4,serverIndex);
	BeginURL=DocURL.indexOf("#",1) + 1;

	urlresult=DocURL.substring(BeginURL,serverIndex);

	//for display, we need to skip after http://, and go to the next slash
	displayresult=DocURL.substring(protocolIndex + 3 ,serverIndex);

	InsertElementAnchor(urlresult, displayresult);
}

function HtmlEncode(text)
{
    return text.replace(/&/g, '&amp').replace(/'/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function TagAttrib(name, value)
{
    return ' '+name+'="'+HtmlEncode(value)+'"';
}

function PrintTag(tagName, needCloseTag, attrib, inner){
    document.write( '<' + tagName + attrib + '>' + HtmlEncode(inner) );
    if (needCloseTag) document.write( '</' + tagName +'>' );
}

function URI(href)
{
    IEVer = window.navigator.appVersion;
    IEVer = IEVer.substr( IEVer.indexOf('MSIE') + 5, 3 );

    return (IEVer.charAt(1)=='.' && IEVer >= '5.5') ?
        encodeURI(href) :
        escape(href).replace(/%3A/g, ':').replace(/%3B/g, ';');
}

function InsertElementAnchor(href, text)
{
    PrintTag('A', true, TagAttrib('HREF', URI(href)), text);
}

//-->
</script>

<body bgcolor="FFFFFF">

<table width="410" cellpadding="3" cellspacing="5">

  <tr>
    <td align="left" valign="middle" width="360">
	<h1 style="COLOR:000000; FONT: 12pt/15pt ����"><!--Problem-->�޷��ҵ���ҳ</h1>
    </td>
  </tr>

  <tr>
<td width="400" colspan="2"> <font style="COLOR:000000; FONT: 9pt/11pt ����">��������������ҳ�����Ѿ�ɾ������������ʱ�����á�</font></td>
  </tr>

  <tr>
    <td width="400" colspan="2"> <font style="COLOR:000000; FONT: 9pt/11pt ����">

	<hr color="#C0C0C0" noshade>

<p>�볢�����в�����</p>

	<ul>
<li>������ڡ���ַ�����м�������ҳ��ַ��������ƴд�Ƿ���ȷ��<br>
      </li>

<li>�� <script>
	  <!--
	  if (!((window.navigator.userAgent.indexOf("MSIE") > 0) && (window.navigator.appVersion.charAt(0) == "2")))
	  {
	  	Homepage();
	  }
	  //-->
	   </script> ��ҳ��Ѱ��ָ��������Ϣ�����ӡ�</li>

<li>����<a href="javascript:history.back(1)">����</a>��ť�����������ӡ�</li>
    </ul>

<h2 style="font:9pt/11pt ����; color:000000">HTTP 404 - �޷��ҵ��ļ�<br> Internet ��Ϣ����<BR></h2>

	<hr color="#C0C0C0" noshade>

	<p>������Ϣ��֧�ָ��ˣ�</p>

<ul>
<li>��ϸ��Ϣ��<br><a href="http://www.microsoft.com/ContentRedirect.asp?prd=iis&sbp=&pver=5.0&pid=&ID=404&cat=web&os=&over=&hrd=&Opt1=&Opt2=&Opt3=" target="_blank">Microsoft ֧��</a>
</li>
</ul>

    </font></td>
  </tr>

</table>
</body>
</html>
<!--
     FILE ARCHIVED ON 02:09:46 Aug 14, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 22:24:35 Dec 15, 2024.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->
<!--
playback timings (ms):
  captures_list: 14.738
  exclusion.robots: 0.047
  exclusion.robots.policy: 0.022
  esindex: 0.023
  cdx.remote: 129.958
  LoadShardBlock: 521.69 (3)
  PetaboxLoader3.datanode: 418.815 (4)
  PetaboxLoader3.resolve: 319.398 (2)
  load_resource: 386.251
-->